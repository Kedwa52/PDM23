function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(100,250,74);
  ellipse(200,200,325,325)
  square(400,50,325)
}